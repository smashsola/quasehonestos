# Quase Honestos

Uma firma quase confiável. Um estagiário sem referências. Seis personagens que têm bons motivos para desconfiar.

**Quase Honestos** é um jogo educativo de comédia sobre manipulação e proteção digital, desenvolvido para o desafio TeenTech 2026. O jogador explora o Trambique OS, conversa com personagens e acompanha as consequências de suas decisões em um universo inteiramente fictício.

## O que já funciona

- Desktop com aplicativos, janelas móveis, fichas, correio e loja de decoração.
- Seis personagens: Nino, Olga, Davi, Yara, Pri e Bento.
- Quatro propostas fictícias: prêmio, suporte remoto, clube e pacote de skins.
- Conversas digitadas, reações próprias, expressões e memória de promessas sobre gratuidade.
- Desconfiança, recusa e irritação: uma recusa pode continuar a conversa; pressão e agressão repetidas podem encerrar o contato.
- Mensagens inesperadas com escolhas de defesa e explicações sobre riscos.
- Progresso salvo no navegador e relatório de partida.
- Respostas locais de reserva: o jogo funciona sem IA.

## IA de personagens

A integração opcional usa Gemini por uma **Cloudflare Pages Function** em `/api/dialogue`. A IA reescreve a resposta com personalidade e contexto; o motor local continua responsável por emoções, etapas, itens, dinheiro e encerramento. Sem chave, sem conexão ou em caso de erro, permanece a fala local.

**Estado:** código de integração preparado; respostas reais dependem da configuração da chave e de validação com a API. Não há chave neste repositório.

Ao usar a IA, as últimas mensagens da conversa e o contexto fictício são enviados ao Google. Não escreva dados pessoais reais. O progresso permanece no navegador; a função não grava um banco de conversas.

## Executar e verificar

Requer Node.js 20 ou mais recente.

```sh
npm run dev
npm test
npm run build
```

O servidor informa o endereço local. O build gera `dist/`, com HTML, CSS, JavaScript e recursos do jogo. O servidor local simples usa as falas offline. Para testar a função Cloudflare localmente, use `npx wrangler pages dev dist` após o build e configure `GEMINI_API_KEY` em `.dev.vars` (arquivo ignorado pelo Git).

## Publicar no Cloudflare Pages

Importe este repositório no Cloudflare Pages e configure:

| Configuração | Valor |
| --- | --- |
| Framework | Nenhum |
| Comando de build | `npm run build` |
| Diretório de saída | `dist` |
| Diretório raiz | raiz do repositório |

A pasta `functions/` deve permanecer na raiz; ela é publicada junto com os arquivos estáticos.

### Colocar a chave no Cloudflare

1. Abra o projeto em **Workers & Pages** e suas configurações de variáveis e segredos.
2. Crie um **segredo** chamado `GEMINI_API_KEY` e cole sua chave Gemini somente nesse campo.
3. Opcionalmente, defina a variável `GEMINI_MODEL`. O padrão do código é `gemini-2.5-flash-lite`; escolha um modelo disponível na sua conta.
4. Publique novamente e teste uma conversa. Sem segredo, o jogo usa as falas locais.

Não coloque a chave no README, no JavaScript do navegador, em commits ou em variáveis públicas. A função limita tamanho do histórico, duração da chamada e saída; configure quotas no projeto Google e proteção de tráfego no Cloudflare antes de divulgação ampla. A validação de origem não substitui autenticação ou um limite global de gastos.

## Referências e autoria

O projeto se inspira na ideia de conversas e aplicativos fictícios de **Scam With Your Friends**, com personagens, humor e conteúdo educativo próprios. A inspiração não implica vínculo com seus criadores.

Tema do TeenTech: **Conexão Segura: Transformando inovação em proteção**. Ferramentas de IA generativa foram utilizadas como apoio à análise, programação e revisão; a equipe deve revisar o resultado e registrar esse uso na documentação da competição.

Todas as ligações, anexos, contas e operações são cenográficas. O jogo não realiza acesso remoto ou transações reais. Seu placar descreve decisões na simulação, não certifica segurança na vida real.

### Documentação técnica

- [Regulamento TeenTech](https://teentech.teckids.org.br/regulamento)
- [Gemini API](https://ai.google.dev/api/generate-content)
- [Cloudflare Pages Functions](https://developers.cloudflare.com/pages/functions/)
